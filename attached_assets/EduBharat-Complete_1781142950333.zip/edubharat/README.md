# 🇮🇳 EduBharat — पढ़ो, सीखो, नौकरी पाओ

> Three complete AI-powered products for Indian students and job seekers.
> **Zero setup. Open any HTML file. Works immediately.**

---

## 📦 What's in this ZIP

| File | Product | Size |
|------|---------|------|
| `index.html` | Landing page (links all 3 products) | ~8 KB |
| `english-guru.html` | Product 1 — AI English Teacher | ~75 KB |
| `interview-ace.html` | Product 2 — Virtual Interview Coach | ~60 KB |
| `rozgar-samachar.html` | Product 3 — Daily AI Newspaper | ~65 KB |

---

## 🚀 Launch in 60 Seconds

### Step 1 — Open immediately (Demo Mode)
Double-click any `.html` file. It opens in your browser and works right away with realistic demo data. No internet, no API key needed to explore all features.

### Step 2 — Enable real AI (2 minutes)
1. Get a free API key from **console.anthropic.com**
2. Open any HTML file in Notepad / VS Code
3. Find this line near the top of `<script>`:
   ```javascript
   const API_KEY = 'YOUR_ANTHROPIC_API_KEY';
   ```
4. Replace with your key (starts with `sk-ant-`)
5. Save and refresh browser

One API key works for all three products.

### Step 3 — Deploy live (30 seconds)
- **Netlify (free):** Go to netlify.com/drop → drag & drop the HTML file → get a live URL instantly
- **GitHub Pages:** Push files to a repo → Settings → Pages → Deploy
- **Replit:** New HTML/CSS/JS Repl → paste contents → Run

---

## 📚 Product 1: English Guru

**What it does:** Teaches English through the student's regional language. Every explanation, grammar rule, and feedback is in their mother tongue.

**Screens:**
- Language selection (12 Indian languages with native script display)
- Dashboard with XP, streak, and daily goals
- Vocabulary Builder — flashcards with regional phonetics ("कैट" for "Cat")
- Grammar Lessons — rules explained in regional language with Indian examples
- Conversation Practice — WhatsApp-style chat with AI playing Bank Manager, Doctor, HR, Shopkeeper etc.
- Daily Quiz — 10 MCQ with 60-second countdown timer
- Progress Dashboard — calendar heatmap + achievement badges
- Profile — settings, certificate download, share progress

**Languages:** Hindi, Bengali, Telugu, Marathi, Tamil, Gujarati, Kannada, Malayalam, Punjabi, Odia, Assamese, Urdu

**LocalStorage key:** `eg_state`

---

## 🎯 Product 2: Interview Ace

**What it does:** Simulates real job interviews with an AI interviewer, evaluates answers across 5 dimensions, and gives actionable feedback.

**Screens:**
- Setup form (9 job categories × 4 experience levels × 4 interview types × 3 difficulties)
- Interview Room — animated AI avatar, live timer, grammar/confidence checker, STAR format hint
- Results — radar chart (Chart.js), Q-by-Q breakdown with model answers, action plan
- Group Discussion Mode — AI plays 3 participants (Rahul, Priya, Amit), evaluates your GD performance
- Aptitude Practice — Quantitative, Logical, Verbal with step-by-step solutions
- History — all past interviews stored with grades and scores
- Common Mistakes — 50 Indian English errors + 20 interview power phrases

**Job categories:** IT/Software, Data/Analytics, Sales, Banking, Govt/SSC, Teaching, Healthcare, BPO, Freshers

**LocalStorage key:** `ia_hist`

---

## 📰 Product 3: Rozgar Samachar

**What it does:** Generates a fresh, personalized daily newspaper every morning for Indian job seekers in their regional language. Content cached in localStorage so it doesn't regenerate on every refresh.

**Newspaper sections:**
1. Lead Story — major career/hiring news (200-250 words)
2. Today's Jobs — 8-10 job listings with filters (Govt/IT/Banking/Teaching/Medical)
3. Skill of the Week — what to learn, free resources, salary expectation
4. Government Scheme Spotlight — eligibility, benefit, how to apply
5. Career Advice Column — written as friendly letter from "Mentor Ji"
6. Trending Skills Chart — CSS bar chart with salary data
7. Success Story — small-town India success in 150 words
8. Entertainment — 2 jokes + interesting fact + daily puzzle + Word of the Day
9. Scrolling Ticker — 5 local news items at the bottom

**Languages:** Hindi, English, Bengali, Telugu, Marathi, Tamil, Gujarati, Kannada, Malayalam, Punjabi

**LocalStorage key:** `rs_profile`, `rs_paper_[date]`

---

## 💳 Payments (when ready to charge)

All three apps have dummy Razorpay payment UI built in. To go live:

1. Create account at **razorpay.com**, complete KYC (2-3 days)
2. Get live keys: `rzp_live_XXXXX` + secret
3. Search for `// PRODUCTION RAZORPAY` in the code — those comments mark exactly where to add real payment logic

---

## 🔧 Customization

### Change Pricing
Search for `data-price` attributes in English Guru, or price values in Interview Ace and Rozgar Samachar setup forms.

### Add a Language
In English Guru: add an entry to the `LANGS` object with all required keys.
In Rozgar Samachar: add an entry to `LANG_CFG` and add to the `<select>` in onboarding.

### Change AI Model
Search for `claude-sonnet-4-6-20251101` — replace with any current model string.

### Improve Demo Data
Each app has hardcoded demo data that shows when no API key is set. Edit:
- English Guru: `DEMO_VOCAB`, `DEMO_QUIZ`, `DEMO_GL` objects
- Interview Ace: `Q_BANKS` object
- Rozgar Samachar: `getDemoPaper()` function

---

## 📊 Estimated API Cost

| Usage | Cost per user per day |
|-------|-----------------------|
| English Guru (5 vocab + 1 quiz) | ~₹1.50–3.00 |
| Interview Ace (1 full interview) | ~₹2.00–4.00 |
| Rozgar Samachar (1 newspaper) | ~₹3.00–6.00 |

Break-even at ₹99/month plan: **~30 paying users covers 300 free users' API costs.**

---

## 🗺️ Roadmap

- [ ] Real Razorpay integration
- [ ] WhatsApp bot delivery (Twilio)
- [ ] PDF text extraction from uploaded documents
- [ ] Email report delivery
- [ ] Mobile apps (React Native wrapper)
- [ ] B2B: sell to coaching institutes, colleges, HR platforms

---

*EduBharat — Making quality career education accessible to every Indian* 🇮🇳
